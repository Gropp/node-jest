"use strict";
//definir de onde virao os dados
//teremos um array simulando um BD
//nomes de usuarios
exports.__esModule = true;
exports.database = void 0;
var database = [
    "Fernando Gropp",
    "Henrique Gropp",
    "Olivia Gropp"
];
exports.database = database;
