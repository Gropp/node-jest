//definir de onde virao os dados
//teremos um array simulando um BD
//nomes de usuarios

const database = [
    "Fernando Gropp",
    "Henrique Gropp",
    "Olivia Gropp"
]

//forma de exporta default uma constante
export {database}